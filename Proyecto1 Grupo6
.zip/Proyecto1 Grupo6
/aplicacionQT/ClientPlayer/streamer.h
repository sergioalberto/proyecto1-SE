#ifndef REPRODUCTOR_H
#define REPRODUCTOR_H

class streamer
{
public:
    streamer();
    void stream(int port);
    void stop();
};

#endif // REPRODUCTOR_H
